INTRUCCIONES PREVIAS:

-En la pantalla inicial introducir el ID en el InputField.
-Todos lo que lo hagais (Miguel, Gines, Adri y Victor), NO SELECCIONEIS EL TOOGLE, de esta forma hareis el juego con las figuras en negro (nos faltan datos de este tipo uwu).
-Una vez esto, le dais al boton ENTER y empezará el juego.

GAMEPLAY:
-Con el click izquierdo arrastrais y moveis las piezas.
-Con el click derecho las rotais 45º.

-Hay dos botones en el juego: un boton para checkear las piezas y otro para skipear la pieza actual.
	+Si la pieza está bien, automaticamente se cargará la pieza siguiente.
	+*IMPORTANTE*: el botón de skipear skipea del todo la pieza, por lo que ya *NO* la podréis volver a hacer.

¡MUCHAS GRACIAS POR HACER EL TESTEO!